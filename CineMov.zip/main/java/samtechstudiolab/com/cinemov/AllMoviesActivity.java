package samtechstudiolab.com.cinemov;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import samtechstudiolab.com.cinemov.DynamicAdapterClasses.AllMoviesAdapter;
import samtechstudiolab.com.cinemov.DynamicModelClasses.NewMoviesModel2;

public class AllMoviesActivity extends AppCompatActivity implements SearchView.OnQueryTextListener {
    RecyclerView allMoviesRecyler;
    List<NewMoviesModel2> newMoviesModels;
    AllMoviesAdapter allMoviesAdapter;
    FirebaseFirestore firebaseFirestore;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_movies);

        firebaseFirestore = FirebaseFirestore.getInstance();
        newMoviesModels = new ArrayList<>();
        allMoviesAdapter = new AllMoviesAdapter(this, newMoviesModels);
        allMoviesRecyler = findViewById(R.id.all_movies_recycler);
        allMoviesRecyler.smoothScrollToPosition(0);
        allMoviesRecyler.setHasFixedSize(true);
        allMoviesRecyler.setLayoutManager(new GridLayoutManager(this, 2));
        allMoviesRecyler.setAdapter(allMoviesAdapter);

        toolbar = findViewById(R.id.all_movies_bar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("All Movies");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        firebaseFirestore.collection("movies").addSnapshotListener(this, new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(QuerySnapshot queryDocumentSnapshots, FirebaseFirestoreException e) {

                try {
                    for (DocumentChange c : queryDocumentSnapshots.getDocumentChanges()) {
                        if (c.getType() == DocumentChange.Type.ADDED) {
                            NewMoviesModel2 moviesModelss = c.getDocument().toObject(NewMoviesModel2.class);
                            newMoviesModels.add(moviesModelss);
                            allMoviesAdapter.notifyDataSetChanged();
                        }
                    }

                } catch (NullPointerException ep) {
                    Log.d("AllMoviesActivity", ep.getMessage());
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.all_menu, menu);
        MenuItem menuItem = menu.findItem(R.id.all_search);
        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        return true;
    }

    @Override
    public boolean onQueryTextSubmit(String s) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String s) {
        String sp = s.toLowerCase();
        makeSearch(sp);
        return true;
    }

    private void makeSearch(String search) {
        ArrayList<NewMoviesModel2> newModel = new ArrayList<>();
        for(NewMoviesModel2 moviesModel2 : newMoviesModels){
            if(moviesModel2.getMovie_original_title().toLowerCase().contains(search)){
                newModel.add(moviesModel2);
            }
            AllMoviesAdapter allMoviesAdapter = new AllMoviesAdapter(AllMoviesActivity.this, newModel);
            allMoviesRecyler.setAdapter(allMoviesAdapter);
            allMoviesAdapter.notifyDataSetChanged();
        }

    }
}
