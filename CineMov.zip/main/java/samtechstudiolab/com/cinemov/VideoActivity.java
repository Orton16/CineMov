package samtechstudiolab.com.cinemov;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import bg.devlabs.fullscreenvideoview.FullscreenVideoView;

public class VideoActivity extends AppCompatActivity {
 FullscreenVideoView fullscreenVideoView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        fullscreenVideoView = findViewById(R.id.Video_view);
        //  String videoUrl = "https://clips.vorwaerts-gmbh.de/VfE_html5.mp4";
        String videoUrl = "http://103.91.144.230/ftpdata/Movies/Hollywood/2019/Best%20Friend%27s%20Betrayal%20%282019%29/Best%20Friend%27s%20Betrayal%20%282019%29%20%20720p%20HDTV%20X264%20Solar.mp4";
        fullscreenVideoView.videoUrl(videoUrl);
        fullscreenVideoView.enableAutoStart();
    }
}
