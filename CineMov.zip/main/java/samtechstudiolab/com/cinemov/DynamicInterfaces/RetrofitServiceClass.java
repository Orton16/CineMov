package samtechstudiolab.com.cinemov.DynamicInterfaces;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.GET;
import retrofit2.http.PUT;
import retrofit2.http.Query;
import samtechstudiolab.com.cinemov.DynamicModelClasses.MovieParentModel;

public interface RetrofitServiceClass {
    //fetch movies which are popular
    @GET("movie/popular")
    Call<MovieParentModel> getPopularMovies(@Query("api_key") String apiKey);


    //fetch movies
    @GET("discover/movie")
    Call<MovieParentModel> getMovies(@Query("api_key") String apiKey);

    // fetch movies which are most rated
    @GET("movie/rated")
    Call<MovieParentModel> getRatedMovies(@Query("api_key") String apiKey);

    //fetch upcoming movies
    @GET("movie/upcoming")
    Call<MovieParentModel> getUpcomingMovies(@Query("api_key") String apiKey);


}
