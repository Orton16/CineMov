package samtechstudiolab.com.cinemov.DynamicModelClasses;

public class NewMoviesModel {
    private String movie_date_released;
    private String movie_director;
    private String movie_genres;
    private String movie_id;
    private String movie_image;
    private String movie_link1080p;
    private String movie_link720p;
    private String movie_original_title;
    private String movie_overview;
    private String movie_rate;
    private String movie_runtime;
    private String movie_stars;
    private String movie_title_desc;
    private String movie_votes;

    public NewMoviesModel() {
    }

    public NewMoviesModel(String movie_date_released, String movie_director, String movie_genres, String movie_id, String movie_image, String movie_link1080p, String movie_link720p, String movie_original_title, String movie_overview, String movie_rate, String movie_runtime, String movie_stars, String movie_title_desc, String movie_votes) {
        this.movie_date_released = movie_date_released;
        this.movie_director = movie_director;
        this.movie_genres = movie_genres;
        this.movie_id = movie_id;
        this.movie_image = movie_image;
        this.movie_link1080p = movie_link1080p;
        this.movie_link720p = movie_link720p;
        this.movie_original_title = movie_original_title;
        this.movie_overview = movie_overview;
        this.movie_rate = movie_rate;
        this.movie_runtime = movie_runtime;
        this.movie_stars = movie_stars;
        this.movie_title_desc = movie_title_desc;
        this.movie_votes = movie_votes;
    }

    public String getMovie_date_released() {
        return movie_date_released;
    }

    public void setMovie_date_released(String movie_date_released) {
        this.movie_date_released = movie_date_released;
    }

    public String getMovie_director() {
        return movie_director;
    }

    public void setMovie_director(String movie_director) {
        this.movie_director = movie_director;
    }

    public String getMovie_genres() {
        return movie_genres;
    }

    public void setMovie_genres(String movie_genres) {
        this.movie_genres = movie_genres;
    }

    public String getMovie_id() {
        return movie_id;
    }

    public void setMovie_id(String movie_id) {
        this.movie_id = movie_id;
    }

    public String getMovie_image() {
        return movie_image;
    }

    public void setMovie_image(String movie_image) {
        this.movie_image = movie_image;
    }

    public String getMovie_link1080p() {
        return movie_link1080p;
    }

    public void setMovie_link1080p(String movie_link1080p) {
        this.movie_link1080p = movie_link1080p;
    }

    public String getMovie_link720p() {
        return movie_link720p;
    }

    public void setMovie_link720p(String movie_link720p) {
        this.movie_link720p = movie_link720p;
    }

    public String getMovie_original_title() {
        return movie_original_title;
    }

    public void setMovie_original_title(String movie_original_title) {
        this.movie_original_title = movie_original_title;
    }

    public String getMovie_overview() {
        return movie_overview;
    }

    public void setMovie_overview(String movie_overview) {
        this.movie_overview = movie_overview;
    }

    public String getMovie_rate() {
        return movie_rate;
    }

    public void setMovie_rate(String movie_rate) {
        this.movie_rate = movie_rate;
    }

    public String getMovie_runtime() {
        return movie_runtime;
    }

    public void setMovie_runtime(String movie_runtime) {
        this.movie_runtime = movie_runtime;
    }

    public String getMovie_stars() {
        return movie_stars;
    }

    public void setMovie_stars(String movie_stars) {
        this.movie_stars = movie_stars;
    }

    public String getMovie_title_desc() {
        return movie_title_desc;
    }

    public void setMovie_title_desc(String movie_title_desc) {
        this.movie_title_desc = movie_title_desc;
    }

    public String getMovie_votes() {
        return movie_votes;
    }

    public void setMovie_votes(String movie_votes) {
        this.movie_votes = movie_votes;
    }
}
