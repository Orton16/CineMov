package samtechstudiolab.com.cinemov.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import samtechstudiolab.com.cinemov.R;
import samtechstudiolab.com.cinemov.model.SplashMovieModel;

public class SliderAdapter extends PagerAdapter {

    Context context;
    List<SplashMovieModel> smm;

    public SliderAdapter(Context context, List<SplashMovieModel> smm) {
        this.context = context;
        this.smm = smm;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.movie_list, null);

        ImageView moviewposter = view.findViewById(R.id.movie_poster);
        TextView movietitle = view.findViewById(R.id.movie_title);
        moviewposter.setImageResource(smm.get(position).getImage());
        movietitle.setText(smm.get(position).getTitle());

        container.addView(view);
        return view;
    }

    @Override
    public int getCount() {
        return smm.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view == o;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }
}
