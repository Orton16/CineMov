package samtechstudiolab.com.cinemov.Adapters;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import samtechstudiolab.com.cinemov.DetailActivity;
import samtechstudiolab.com.cinemov.R;
import samtechstudiolab.com.cinemov.model.CategoryModel;


public class CatAdapter extends RecyclerView.Adapter<CatAdapter.ViewHolder> {

    Context context;
    List<CategoryModel> categoryModel;

    public CatAdapter(Context context, List<CategoryModel> categoryModel) {
        this.context = context;
        this.categoryModel = categoryModel;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.top_categories, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int i) {

        String title = categoryModel.get(i).getTitle();
        int image = categoryModel.get(i).getImage();
        int count = categoryModel.get(i).getCount();
        final String a = String.valueOf(image);
        final String b = String.valueOf(count);


        viewHolder.catImage.setImageResource(image);
        viewHolder.catTitle.setText(title);
        viewHolder.catCount.setText(""+count);

        viewHolder.catImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = viewHolder.getAdapterPosition();
                Toast.makeText(context, "Movie type about to watch is " + categoryModel.get(position).getTitle(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("title", categoryModel.get(position).getTitle());
                intent.putExtra("img", a);
                intent.putExtra("count", b);
                ActivityOptions o = ActivityOptions.makeSceneTransitionAnimation((Activity) context, viewHolder.catImage, "move");
                context.startActivity(intent, o.toBundle());


            }
        });
    }

    @Override
    public int getItemCount() {
        return categoryModel.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView catTitle, catCount;
        ImageView catImage;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);

            catCount = itemView.findViewById(R.id.cat_count);
            catTitle = itemView.findViewById(R.id.cat_title);
            catImage = itemView.findViewById(R.id.cat_image);


        }
    }
}
