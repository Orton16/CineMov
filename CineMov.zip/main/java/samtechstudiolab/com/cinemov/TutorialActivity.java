package samtechstudiolab.com.cinemov;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TutorialActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);

        //This is the activity where the backend logincs will be hosted
        // we will create an app which will dispplay any text we write when a button is clicked
        //going to the activity_tutoral.xml
        // next part we shall look at how to link and make communication between these widgets
    }
}
