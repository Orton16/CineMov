package samtechstudiolab.com.cinemov;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.jgabrielfreitas.core.BlurImageView;

public class DetailActivity extends AppCompatActivity {
    TextView title, desc, voteCount, averageVote, releaseDate, pop, gen, lag;
    ImageView img, imag2;
    BlurImageView blurImageView;

    //DocumentView desc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        title = findViewById(R.id.title);
        desc = findViewById(R.id.desc);
        // img = findViewById(R.id.img);
        imag2 = findViewById(R.id.imag2);
        voteCount = findViewById(R.id.vote_count);
        averageVote = findViewById(R.id.average_vote);
        releaseDate = findViewById(R.id.release_date);
        pop = findViewById(R.id.popularity);
        gen = findViewById(R.id.genres);
        lag = findViewById(R.id.lang);
        blurImageView = (BlurImageView) findViewById(R.id.img);


        getStringExtras();
    }

    private void getStringExtras() {


        String title = getIntent().getStringExtra("title");
        String desc = getIntent().getStringExtra("overview");
        String genres = getIntent().getStringExtra("genres");
        String language = getIntent().getStringExtra("language");
        String url = getIntent().getStringExtra("url");
        String votecount = getIntent().getStringExtra("votecount");
        String averagecount = getIntent().getStringExtra("averagecount");
        String popularity = getIntent().getStringExtra("popularity");
        String releaseDate = getIntent().getStringExtra("releaseDate");


        this.title.setText(title);
        // this.desc.getDocumentLayoutParams().setTextAlignment(TextAlignment.JUSTIFIED);
        //this.desc.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY );
        this.desc.setText(desc);
        this.voteCount.setText("Ratings: " + votecount);
        this.lag.setText("Language: " + language);
        this.gen.setText("Genres: " + genres);
        this.releaseDate.setText("Release Date: " + releaseDate);
        this.pop.setText("Movie Popularity: " + popularity);
        this.averageVote.setText("Average Votes: " + averagecount);


        Glide.with(getApplicationContext()).load(url).placeholder(R.drawable.bw_icon_big).into(blurImageView);
        blurImageView.setBlur(50);

        Glide.with(getApplicationContext()).load(url).placeholder(R.drawable.bw_icon_big).into(imag2);
        //this.img.setImageResource(Integer.parseInt(image));
    }

    public void playVideo(View view) {
        Intent intent = new Intent(getApplicationContext(), VideoViewActivity.class);
        // intent.putExtra();
        // intent.putExtra();
        // intent.putExtra();
        //intent.putExtra();
        startActivity(intent);
    }

}
