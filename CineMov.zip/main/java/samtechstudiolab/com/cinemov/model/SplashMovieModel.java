package samtechstudiolab.com.cinemov.model;

public class SplashMovieModel {
    int image;
    String title, description, ratings;
    double duration;
    int year;

    public SplashMovieModel() {
    }

    public SplashMovieModel(int image, String title, String description, String ratings, double duration, int year) {
        this.image = image;
        this.title = title;
        this.description = description;
        this.ratings = ratings;
        this.duration = duration;
        this.year = year;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRatings() {
        return ratings;
    }

    public void setRatings(String ratings) {
        this.ratings = ratings;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
