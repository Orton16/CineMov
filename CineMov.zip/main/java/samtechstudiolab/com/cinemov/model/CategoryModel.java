package samtechstudiolab.com.cinemov.model;

public class CategoryModel {
    String title;
    int image, count;

    public CategoryModel() {
    }

    public CategoryModel(String title, int image, int count) {
        this.title = title;
        this.image = image;
        this.count = count;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
