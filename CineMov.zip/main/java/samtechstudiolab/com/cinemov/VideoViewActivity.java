package samtechstudiolab.com.cinemov;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;

public class VideoViewActivity extends AppCompatActivity {

    Uri videoUri;
    SimpleExoPlayerView exoPlayerView;
    SimpleExoPlayer exoPlayer;
    TextView Title;
    ImageView Download, More;
    Toolbar toolbar;
    //String videoURL = "http://blueappsoftware.in/layout_design_android_blog.mp4";
    /*
     * movie sites
     * https://mihanpix.com
     * film2movie.ws
     * salamdl.info
     * */
    // String videoURL = "http://dl9.f2m.io/film/Bum.ble.bee.2018.720p.b.lu.ry.MkvCage.Film2Movie_WS.mkv";
    boolean isLand = false;
    MediaSource mediaSource;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_view);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);


        // VideoView videoView = findViewById(R.id.videoView);
        Title = findViewById(R.id.title_vid);
        Download = findViewById(R.id.download);
        More = findViewById(R.id.more);
        toolbar = findViewById(R.id.vid_bar);

        String title = getIntent().getStringExtra("title");
        String overview = getIntent().getStringExtra("overview");
        String genres = getIntent().getStringExtra("genres");
        String language = getIntent().getStringExtra("language");
        String url = getIntent().getStringExtra("img");
        String votecount = getIntent().getStringExtra("count");
        String averagecount = getIntent().getStringExtra("average");
        String titleDesc = getIntent().getStringExtra("title_desc");
        String releaseDate = getIntent().getStringExtra("release");
        String id = getIntent().getStringExtra("id");
        String linkOne = getIntent().getStringExtra("720p");
        String linkTwo = getIntent().getStringExtra("1081p");
        String runtime = getIntent().getStringExtra("runtime");
        String stars = getIntent().getStringExtra("stars");
        String director = getIntent().getStringExtra("director");
        final String videoURL = linkTwo;
        final String videoURL2 = linkTwo;

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(title);
        //getSupportActionBar().setLogo(R.mipmap.ic_launcher);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        Title.setText(title);
        // videoUri = Uri.parse("https://clips.vorwaerts-gmbh.de/VfE_html5.mp4");
        // videoUri = Uri.parse("https://youtube.com/watch?v=2DCD-PZMiNg");
        // videoUri = Uri.parse("https://clips.vorwaerts-gmbh.de/VfE_html5.mp4");
        // videoView.setVideoURI(videoUri);
        // videoView.start();


        if (toolbar.getVisibility() == View.VISIBLE) {
            Handler h = new Handler();
            Runnable r = new Runnable() {
                @Override
                public void run() {
                    toolbar.setVisibility(View.GONE);
                }
            };
            h.postDelayed(r, 5000);
        }

        if (isLand) {
            isLandscape();
        }
        exoPlayerView = (SimpleExoPlayerView) findViewById(R.id.exo_player_view);


        exoPlayerView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (toolbar.getVisibility() == View.VISIBLE ) {
                    toolbar.setVisibility(View.GONE);

                } else {
                    toolbar.setVisibility(View.VISIBLE);

                }

                return false;
            }
        });
        exoPlayerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(VideoViewActivity.this, "The Onclick Listener is now working", Toast.LENGTH_SHORT).show();
            }
        });

        try {


            BandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
            TrackSelector trackSelector = new DefaultTrackSelector(new AdaptiveTrackSelection.Factory(bandwidthMeter));
            exoPlayer = ExoPlayerFactory.newSimpleInstance(this, trackSelector);

            Uri videoURI = Uri.parse(videoURL);

            DefaultHttpDataSourceFactory dataSourceFactory = new DefaultHttpDataSourceFactory("exoplayer_video");
            ExtractorsFactory extractorsFactory = new DefaultExtractorsFactory();
            mediaSource = new ExtractorMediaSource(videoURI, dataSourceFactory, extractorsFactory, null, null);


            exoPlayerView.setPlayer(exoPlayer);
            exoPlayer.prepare(mediaSource);
            exoPlayer.setPlayWhenReady(true);


        } catch (Exception e) {
            Log.e("MainAcvtivity", " exoplayer error " + e.toString());
            AlertDialog.Builder builder = new AlertDialog.Builder(VideoViewActivity.this);
            builder.setMessage(e.getMessage());
            builder.setPositiveButton("Close", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            }).setNegativeButton("Try Again", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    BandwidthMeter bandwidthMeter = new DefaultBandwidthMeter();
                    TrackSelector trackSelector = new DefaultTrackSelector(new AdaptiveTrackSelection.Factory(bandwidthMeter));
                    exoPlayer = ExoPlayerFactory.newSimpleInstance(VideoViewActivity.this, trackSelector);

                    Uri videoURI = Uri.parse(videoURL2);

                    DefaultHttpDataSourceFactory dataSourceFactory = new DefaultHttpDataSourceFactory("exoplayer_video");
                    ExtractorsFactory extractorsFactory = new DefaultExtractorsFactory();
                    mediaSource = new ExtractorMediaSource(videoURI, dataSourceFactory, extractorsFactory, null, null);


                    exoPlayerView.setPlayer(exoPlayer);
                    exoPlayer.prepare(mediaSource);
                    exoPlayer.setPlayWhenReady(true);
                }
            });
            builder.show();
        }

        Download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeDownload();
            }
        });

        More.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeMore();
            }
        });


    }

    private void makeMore() {
        final CharSequence args[] = new CharSequence[]{
                "Movie Chat Room",
                "Offline Movies",
                "Share",
                "Movie Details",
                "Login",
                "About"
        };
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("More Options");
        builder.setItems(args, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Toast.makeText(VideoViewActivity.this, , Toast.LENGTH_SHORT).show();
            }
        });
        builder.show();
    }

    private void makeDownload() {
        Toast.makeText(this, "Saving Movie to Offline", Toast.LENGTH_SHORT).show();
        //DownloadManager manager =  (DownloadManager)getAc
    }


    private void makeLike() {
    }


    private void makeComment() {
    }


    private void makeShare() {
    }


    private void isLandscape() {
        VideoViewActivity.this.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE);

    }


    @Override
    public void onBackPressed() {
        exoPlayer.stop();
        exoPlayer.release();
        exoPlayer = null;
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        try {
            super.onDestroy();
            exoPlayer.stop();
            exoPlayer.release();
            exoPlayer = null;
        } catch (NullPointerException ep) {

        }


    }

    @Override
    protected void onStop() {

        try {
            super.onStop();
            exoPlayer.stop();
            exoPlayer.release();
            exoPlayer = null;
        } catch (NullPointerException ep) {

        }

    }

    @Override
    protected void onPause() {

        try {
            super.onPause();
            exoPlayer.stop();
            exoPlayer.release();
            exoPlayer = null;
        } catch (NullPointerException ep) {

        }

    }

    public void see(View view) {
        Title.setVisibility(View.VISIBLE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.all_videos_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int vid_menu = item.getItemId();

        if (vid_menu == R.id.downloadz) {
            makeDownload();
        }
        if (vid_menu == R.id.commentz) {
            makeComment();
        }
        if (vid_menu == R.id.likez) {
            makeLike();
        }
        if (vid_menu == R.id.sharez) {
            makeShare();
        }
        if (vid_menu == R.id.aboutz) {
            makeAbout();
        }
        if (vid_menu == R.id.helpz) {
            makeHelp();
        }
        if (vid_menu == R.id.chatz) {
            makeChat();
        }
        if (vid_menu == R.id.offlinez) {
            makeOffline();
        }
        if (vid_menu == R.id.user_settingz) {
            makeUserSettings();
        }
        if (vid_menu == R.id.mo_detailz) {
            makeMovieDetails();
        }
        if (vid_menu == R.id.sharez) {
            makeShare();
        }


        return true;
    }

    private void makeAbout() {
    }

    private void makeHelp() {
    }

    private void makeMovieDetails() {
    }

    private void makeUserSettings() {
    }

    private void makeOffline() {
    }

    private void makeChat() {
    }
}