package samtechstudiolab.com.cinemov.DynamicAdapterClasses;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import samtechstudiolab.com.cinemov.DetailActivity;
import samtechstudiolab.com.cinemov.DynamicModelClasses.MoviesResponseModel;
import samtechstudiolab.com.cinemov.R;

public class PopularMovieAdapter extends RecyclerView.Adapter<PopularMovieAdapter.ViewHolder> {
    String a = "";
    Context context;
    List<MoviesResponseModel> moviesResponseModels;

    public PopularMovieAdapter(Context context, List<MoviesResponseModel> moviesResponseModels) {
        this.context = context;
        this.moviesResponseModels = moviesResponseModels;
    }

    public PopularMovieAdapter(Context context) {
        this.context = context;
        // this.moviesResponseModels = moviesResponseModels;
    }


    @NonNull
    @Override
    public PopularMovieAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.popular_movies, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final PopularMovieAdapter.ViewHolder viewHolder, int i) {

        MoviesResponseModel responseModel = moviesResponseModels.get(i);
        final String title = responseModel.getTitle();
        final String url = responseModel.getPoster_path();
        final String overview = responseModel.getOverview();
        final String original_language = responseModel.getOriginal_language();
        final String voteCount = String.valueOf(responseModel.getVote_count());
        final String averageVote = String.valueOf(responseModel.getVote_average());
        final String popularity = String.valueOf(responseModel.getPopularity());
        final String release_date = String.valueOf(responseModel.getRelease_date());


        final List<Integer> genres = responseModel.getGenre_ids();
        int index = genres.size();

        a = genres.toString();

/*
*


        String sortGenre = "";

        for (int j = 0; i <= responseModel.getGenre_ids().size(); i++) {
            switch (i) {


                case 28:
                    sortGenre += " Action";
                case 12:
                    sortGenre += " Adventure";
                case 16:
                    sortGenre += " Animation";
                case 35:
                    sortGenre += " Commedy";
                case 80:
                    sortGenre += " Crime";
                case 90:
                    sortGenre += " Documentary";
                case 18:
                    sortGenre += " Drama";
                case 10751:
                    sortGenre += " Family";
                case 14:
                    sortGenre += " Fantasy";
                case 36:
                    sortGenre += " History";
                case 27:
                    sortGenre += " Horror";
                case 10402:
                    sortGenre += " Music";
                case 9648:
                    sortGenre += " Mystery";
                case 10749:
                    sortGenre += " Romance";
                case 878:
                    sortGenre += " Sci-Fic";
                case 10770:
                    sortGenre += " TV Movie";
                case 53:
                    sortGenre += " Thriller";
                case 10752:
                    sortGenre += " War";
                case 37:
                    sortGenre += " Western";

                default:
                     return;

            }
        }

* */

        viewHolder.setDetails(url, title);
        viewHolder.image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = viewHolder.getAdapterPosition();
                Intent details = new Intent(context, DetailActivity.class);
                details.putExtra("title", title);
                details.putExtra("genres", a);
                details.putExtra("releaseDate", release_date);
                details.putExtra("popularity", popularity);
                details.putExtra("language", original_language);
                details.putExtra("url", url);
                details.putExtra("overview", overview);
                details.putExtra("votecount", voteCount);
                details.putExtra("averagecount", averageVote);
                //  ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation((Activity) context, viewHolder.image, "move");
                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation((Activity) context, viewHolder.image, "movie");
                context.startActivity(details, options.toBundle());
            }
        });
    }

    @Override
    public int getItemCount() {
        return moviesResponseModels.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ImageView image;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);


            title = itemView.findViewById(R.id.popular_movie_title);
            image = itemView.findViewById(R.id.popular_movie_image);

        }

        public void setDetails(String u, String t) {
            title.setText(t);
            Glide.with(context).load(u).placeholder(R.drawable.bw_icon_small).into(image);
        }
    }
}
