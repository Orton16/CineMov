package samtechstudiolab.com.cinemov.DynamicAdapterClasses;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.List;

import samtechstudiolab.com.cinemov.DynamicModelClasses.NewMoviesModel;
import samtechstudiolab.com.cinemov.NewDetaisActivity;
import samtechstudiolab.com.cinemov.R;


public class NewMoviesAdapter extends RecyclerView.Adapter<NewMoviesAdapter.ViewHolder> {

    Context context;
    List<NewMoviesModel> NewMovies;

    public NewMoviesAdapter(Context context, List<NewMoviesModel> NewMovies) {
        this.context = context;
        this.NewMovies = NewMovies;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.top_categories, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int i) {
        try {
            final String title = NewMovies.get(i).getMovie_original_title();
            final String titleDesc = NewMovies.get(i).getMovie_title_desc();
            final String url720 = NewMovies.get(i).getMovie_link720p();
            final String url1080 = NewMovies.get(i).getMovie_link1080p();
            final String url = NewMovies.get(i).getMovie_image();
            final String overview = NewMovies.get(i).getMovie_overview();
            final String original_language = NewMovies.get(i).getMovie_date_released().replaceAll("1234567890-", "");
            final String voteCount = String.valueOf(NewMovies.get(i).getMovie_votes());
            final String averageVote = String.valueOf(NewMovies.get(i).getMovie_rate());
            final String runtime = String.valueOf(NewMovies.get(i).getMovie_runtime());
            final String release_date = String.valueOf(NewMovies.get(i).getMovie_date_released());
            final String stars = String.valueOf(NewMovies.get(i).getMovie_stars());
            final String genres = String.valueOf(NewMovies.get(i).getMovie_genres());
            final String id = String.valueOf(NewMovies.get(i).getMovie_id());
            final String director = String.valueOf(NewMovies.get(i).getMovie_director());

            Glide.with(context).load(url).placeholder(R.drawable.bw_icon_small).into(viewHolder.catImage);
            viewHolder.catTitle.setText(title);
            viewHolder.catCount.setText(original_language);

            viewHolder.catImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = viewHolder.getAdapterPosition();
                    //Toast.makeText(context, "Movie type about to watch is " + categoryModel.get(position).getTitle(), Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(context, NewDetaisActivity.class);
                    intent.putExtra("title", title);
                    intent.putExtra("img", url);
                    intent.putExtra("count", voteCount);
                    intent.putExtra("title_desc", titleDesc);
                    intent.putExtra("720p", url720);
                    intent.putExtra("1081p", url1080);
                    intent.putExtra("overview", overview);
                    intent.putExtra("language", original_language);
                    intent.putExtra("average", averageVote);
                    intent.putExtra("runtime", runtime);
                    intent.putExtra("stars", stars);
                    intent.putExtra("genres", genres);
                    intent.putExtra("id", id);
                    intent.putExtra("release", release_date);
                    intent.putExtra("director", director);

                    ActivityOptions o = ActivityOptions.makeSceneTransitionAnimation((Activity) context, viewHolder.catImage, "movie");
                    context.startActivity(intent, o.toBundle());
                }


            });
        } catch (Exception ep) {
            Toast.makeText(context, ep.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() {
        return NewMovies.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView catTitle, catCount;
        ImageView catImage;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);

            catCount = itemView.findViewById(R.id.cat_count);
            catTitle = itemView.findViewById(R.id.cat_title);
            catImage = itemView.findViewById(R.id.cat_image);

        }
        /**
         * movie_date_released;
         * movie_director;
         * movie_genres;
         * movie_id;
         * movie_image;
         * movie_link1080p;
         * movie_link720p;
         * movie_original_title;
         * movie_overview;
         * movie_rate;
         * movie_runtime;
         * movie_stars;
         * movie_title_desc;
         * movie_votes;
         *
         */
    }

}
