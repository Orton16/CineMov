package samtechstudiolab.com.cinemov.DynamicAdapterClasses;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import samtechstudiolab.com.cinemov.R;
import com.bumptech.glide.Glide;

import org.w3c.dom.Text;

import java.util.List;

import samtechstudiolab.com.cinemov.DynamicModelClasses.NewMoviesModel2;
import samtechstudiolab.com.cinemov.NewDetaisActivity;


public class AllMoviesAdapter extends RecyclerView.Adapter<AllMoviesAdapter.ViewHolder> {

    Context context;
    List<NewMoviesModel2> NewMovies;

    public AllMoviesAdapter(Context context, List<NewMoviesModel2> NewMovies) {
        this.context = context;
        this.NewMovies = NewMovies;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.all_movies_list, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int i) {
        final String title = NewMovies.get(i).getMovie_original_title();
        final String titleDesc = NewMovies.get(i).getMovie_title_desc();
        final String url720 = NewMovies.get(i).getMovie_link720p();
        final String url1080 = NewMovies.get(i).getMovie_link1080p();
        final String url= NewMovies.get(i).getMovie_image();
        final String overview = NewMovies.get(i).getMovie_overview();
        final String original_language = NewMovies.get(i).getMovie_date_released();
        final String voteCount = String.valueOf(NewMovies.get(i).getMovie_votes());
        final String averageVote = String.valueOf(NewMovies.get(i).getMovie_rate());
        final String runtime = String.valueOf(NewMovies.get(i).getMovie_runtime());
        final String release_date = String.valueOf(NewMovies.get(i).getMovie_date_released());
        final String stars = String.valueOf(NewMovies.get(i).getMovie_stars());
        final String genres = String.valueOf(NewMovies.get(i).getMovie_genres());
        final String id = String.valueOf(NewMovies.get(i).getMovie_id());
        final String director = String.valueOf(NewMovies.get(i).getMovie_director());

      viewHolder.setAll(title, release_date, averageVote + "||"+ voteCount, url);

        viewHolder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = viewHolder.getAdapterPosition();
                //Toast.makeText(context, "Movie type about to watch is " + categoryModel.get(position).getTitle(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(context, NewDetaisActivity.class);
                intent.putExtra("title", title);
                intent.putExtra("img", url);
                intent.putExtra("count", voteCount);
                intent.putExtra("title_desc", titleDesc);
                intent.putExtra("720p", url720);
                intent.putExtra("1081p", url1080);
                intent.putExtra("overview", overview);
                intent.putExtra("language", original_language);
                intent.putExtra("average", averageVote);
                intent.putExtra("runtime", runtime);
                intent.putExtra("stars", stars);
                intent.putExtra("genres", genres);
                intent.putExtra("id", id);
                intent.putExtra("release", release_date);
                intent.putExtra("director", director);
                ActivityOptions o = ActivityOptions.makeSceneTransitionAnimation((Activity) context, viewHolder.imageView, "movie");
                context.startActivity(intent, o.toBundle());


            }
        });
    }

    @Override
    public int getItemCount() {
        return NewMovies.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title, date_relese, rate;
        ImageView imageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.all_movie_title);
            date_relese = itemView.findViewById(R.id.all_movie_daterelease);
            rate = itemView.findViewById(R.id.all_movie_rateings_votes);
            imageView = itemView.findViewById(R.id.all_movie_image);
        }

        public void setAll(String tl, String dr, String rt, String iv){
            title.setText(tl);
            date_relese.setText(dr);
            rate.setText(rt);
            Glide.with(context).load(iv).placeholder(R.drawable.bw_icon_small).into(imageView);
        }
    }
}
