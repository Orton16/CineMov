package samtechstudiolab.com.cinemov;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.jgabrielfreitas.core.BlurImageView;

public class NewDetaisActivity extends AppCompatActivity {
    TextView Title, Desc, VoteCount, AverageVote, ReleaseDate, Pop, Gen, Lag, Runt;
    ImageView Img, Imag2;
    BlurImageView blurImageView;
    String title;
    String overview;
    String genres;
    String language;
    String url;
    String votecount;
    String averagecount;
    String titleDesc;
    String releaseDate;
    String id;
    String linkOne;
    String linkTwo;
    String runtime;
    String stars;
    String director;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_detais);
        Title = findViewById(R.id.title2);
        Desc = findViewById(R.id.desc2);
        // img = findViewById(R.id.img);
        Imag2 = findViewById(R.id.imag22);
        VoteCount = findViewById(R.id.vote_count2);
        AverageVote = findViewById(R.id.average_vote2);
        ReleaseDate = findViewById(R.id.release_date2);
        Pop = findViewById(R.id.popularity2);
        Gen = findViewById(R.id.genres2);
        Runt = findViewById(R.id.runtime);
        Lag = findViewById(R.id.lang2);
        blurImageView = (BlurImageView) findViewById(R.id.img2);


        title = getIntent().getStringExtra("title");
        overview = getIntent().getStringExtra("overview");
        genres = getIntent().getStringExtra("genres");
        language = getIntent().getStringExtra("language");
        url = getIntent().getStringExtra("img");
        votecount = getIntent().getStringExtra("count");
        averagecount = getIntent().getStringExtra("average");
        titleDesc = getIntent().getStringExtra("title_desc");
        releaseDate = getIntent().getStringExtra("release");
        id = getIntent().getStringExtra("id");
        linkOne = getIntent().getStringExtra("720p");
        linkTwo = getIntent().getStringExtra("1081p");
        runtime = getIntent().getStringExtra("runtime");
        stars = getIntent().getStringExtra("stars");
        director = getIntent().getStringExtra("director");


        this.Title.setText(titleDesc);
        this.Desc.setText(overview + "\n\n" + "Staring : " + stars);
        this.VoteCount.setText("Ratings: " + votecount);
        this.Lag.setText("Language: " + language.replaceAll("1234567890-", ""));
        this.Gen.setText("Genres: " + genres);
        this.Runt.setText("Runtime : " + runtime);
        this.ReleaseDate.setText("Release Date: " + releaseDate);
        this.Pop.setText("Movie Director: " + director);
        this.AverageVote.setText("Average Votes: " + averagecount);
        Glide.with(getApplicationContext()).load(url).placeholder(R.drawable.bw_icon_big).into(blurImageView);
        blurImageView.setBlur(50);

        Glide.with(getApplicationContext()).load(url).placeholder(R.drawable.bw_icon_big).into(Imag2);
    }

    public void playVideo(View view) {

        Intent intent = new Intent(getApplicationContext(), VideoViewActivity.class);
        intent.putExtra("title", title);
        intent.putExtra("img", url);
        intent.putExtra("count", votecount);
        intent.putExtra("title_desc", titleDesc);
        intent.putExtra("720p", linkOne);
        intent.putExtra("1081p", linkTwo);
        intent.putExtra("overview", overview);
        intent.putExtra("language", language);
        intent.putExtra("average", averagecount);
        intent.putExtra("runtime", runtime);
        intent.putExtra("stars", stars);
        intent.putExtra("genres", genres);
        intent.putExtra("id", id);
        intent.putExtra("release", releaseDate);
        intent.putExtra("director", director);
        //ActivityOptions o = ActivityOptions.makeSceneTransitionAnimation(getApplicationContext(), catImage, "movie");
        startActivity(intent);

    }
}
