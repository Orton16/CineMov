package samtechstudiolab.com.cinemov;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;

import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import io.paperdb.Paper;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import samtechstudiolab.com.cinemov.Adapters.SliderAdapter;
import samtechstudiolab.com.cinemov.DynamicAdapterClasses.NewMoviesAdapter;
import samtechstudiolab.com.cinemov.DynamicAdapterClasses.PopularMovieAdapter;
import samtechstudiolab.com.cinemov.DynamicClientService.RetrofitClientService;
import samtechstudiolab.com.cinemov.DynamicInterfaces.RetrofitServiceClass;
import samtechstudiolab.com.cinemov.DynamicModelClasses.MovieParentModel;
import samtechstudiolab.com.cinemov.DynamicModelClasses.MoviesResponseModel;
import samtechstudiolab.com.cinemov.DynamicModelClasses.NewMoviesModel;
import samtechstudiolab.com.cinemov.model.SplashMovieModel;

public class HomeActivity extends AppCompatActivity implements SearchView.OnQueryTextListener {

    List<SplashMovieModel> splash;
    ViewPager viewPager;
    Toolbar toolbar;
    TabLayout tabLayout;
    RecyclerView recyclerView;
    RecyclerView popularRecycler;
    // List<CategoryModel> categoryModel;
    List<NewMoviesModel> moviesModel;
    //CatAdapter catAdapter;
    PopularMovieAdapter popularMovieAdapter;
    NewMoviesAdapter moviesAdapter;
    FirebaseFirestore firebaseFirestore;

    PopularMovieAdapter popularMovieAdapter1;
    RetrofitServiceClass RSC;
    Context context;
    TextView seeAll;
    String name;
    //Integer phone = 0240841448;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        viewPager = findViewById(R.id.view_pager);
        toolbar = findViewById(R.id.include_home_bar);
        tabLayout = findViewById(R.id.tab_indicator);

        context = HomeActivity.this;

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("CinePlae");
        getSupportActionBar().setLogo(R.mipmap.ic_launcher);
        firebaseFirestore = FirebaseFirestore.getInstance();
        seeAll = findViewById(R.id.see_all);
        seeAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent allmovies = new Intent(getApplicationContext(), AllMoviesActivity.class);
                startActivity(allmovies);
            }
        });
        //Paper db for storing movies offline
        Paper.init(this);
/*

API Key (v3 auth)
12ab57e6f5078e3777669668ea90c5d0
API Read Access Token (v4 auth)
eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIxMmFiNTdlNmY1MDc4ZTM3Nzc2Njk2NjhlYTkwYzVkMCIsInN1YiI6IjVjYTBlMjFhOTI1MTQxMWExODA3Yzc4NyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.y4_6ZMrcsz18Ro1IW0sns5hXbEHbFE2HVvL8D2sjrbg
Example API Request
https://api.themoviedb.org/3/movie/550?api_key=12ab57e6f5078e3777669668ea90c5d0


Usage
First, give the blurring view a reference to the view to be blurred:

blurringView.setBlurredView(blurredView);
and then whenever the blurred view changes, invalidate the blurring view:

blurringView.invalidate();



movies url http://103.91.144.230/ftpdata/Movies/Hollywood/2019/
 */


        splash = new ArrayList<>();
        splash.add(new SplashMovieModel(R.drawable.review, "Ant Man Review", "In 1989, scientist Hank Pym resigns from S.H.I.E.L.D. after discovering their attempt to replicate his Ant-Man shrinking technology. Believing the technology is dangerous, Pym vows to hide it as long as he lives.", "3", 2.30, 2018));
        splash.add(new SplashMovieModel(R.drawable.review_two, "Justice League", "In 1989, scientist Hank Pym resigns from S.H.I.E.L.D. after discovering their attempt to replicate his Ant-Man shrinking technology. Believing the technology is dangerous, Pym vows to hide it as long as he lives.", "3", 2.10, 2017));
        splash.add(new SplashMovieModel(R.drawable.review_three, "Jurassic", "In 1989, scientist Hank Pym resigns from S.H.I.E.L.D. after discovering their attempt to replicate his Ant-Man shrinking technology. Believing the technology is dangerous, Pym vows to hide it as long as he lives.", "3", 1.50, 2017));
        splash.add(new SplashMovieModel(R.drawable.review_four, "Avengers Infinity War", "In 1989, scientist Hank Pym resigns from S.H.I.E.L.D. after discovering their attempt to replicate his Ant-Man shrinking technology. Believing the technology is dangerous, Pym vows to hide it as long as he lives.", "3", 2.55, 2015));
        splash.add(new SplashMovieModel(R.drawable.review_five, "Cape Cope", "In 1989, scientist Hank Pym resigns from S.H.I.E.L.D. after discovering their attempt to replicate his Ant-Man shrinking technology. Believing the technology is dangerous, Pym vows to hide it as long as he lives.", "3", 2.20, 2018));

        SliderAdapter sa = new SliderAdapter(this, splash);
        viewPager.setAdapter(sa);
        tabLayout.setupWithViewPager(viewPager, true);

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new HomeActivity.AutoSlide(), 5000, 5000);

        recyclerView = findViewById(R.id.cat_recycler);
        // categoryModel = new ArrayList<>();
        //catAdapter = new CatAdapter(this, categoryModel);
        moviesModel = new ArrayList<>();
        moviesAdapter = new NewMoviesAdapter(this, moviesModel);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayout.HORIZONTAL, false));
        recyclerView.setAdapter(moviesAdapter);
        /*popularMovieAdapter1 = new PopularMovieAdapter(this);
        categoryModel.add(new CategoryModel("Action", R.drawable.action, 5));
        categoryModel.add(new CategoryModel("Romance", R.drawable.romance, 25));
        categoryModel.add(new CategoryModel("Drama", R.drawable.dramma, 55));
        categoryModel.add(new CategoryModel("Sci-Fic", R.drawable.scific, 55));
        categoryModel.add(new CategoryModel("Comedy", R.drawable.commedy, 55));
        categoryModel.add(new CategoryModel("Crime", R.drawable.crime, 75));
        categoryModel.add(new CategoryModel("Horror", R.drawable.horror, 54));
        categoryModel.add(new CategoryModel("Documentary", R.drawable.documenatary, 51));
        categoryModel.add(new CategoryModel("Animation", R.drawable.animation, 52));
        categoryModel.add(new CategoryModel("Adventure", R.drawable.adventure, 51));
        categoryModel.add(new CategoryModel("Sports", R.drawable.sports, 45));
        categoryModel.add(new CategoryModel("Thriller", R.drawable.thriller, 85));

*/
        makeFetch();


        RSC = RetrofitClientService.getClientService().create(RetrofitServiceClass.class);
        Call<MovieParentModel> movieParentModelCall = RSC.getPopularMovies(BuildConfig.The_Movie_Api_Key);

        movieParentModelCall.enqueue(new Callback<MovieParentModel>() {
            @Override
            public void onResponse(Call<MovieParentModel> call, Response<MovieParentModel> response) {
                MovieParentModel movieParentModel = response.body();
                if (movieParentModel != null) {
                    List<MoviesResponseModel> moviesResponseModels = movieParentModel.getResults();
                    popularMovieAdapter = new PopularMovieAdapter(HomeActivity.this, moviesResponseModels);
                    popularRecycler = findViewById(R.id.top_movies_recycler);
                    popularRecycler.smoothScrollToPosition(0);
                    popularRecycler.setHasFixedSize(true);
                    popularRecycler.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayout.HORIZONTAL, false));
                    popularRecycler.setAdapter(popularMovieAdapter);
                    popularMovieAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<MovieParentModel> call, Throwable t) {

            }
        });

    }

    private void makeFetch() {
        firebaseFirestore.collection("movies").limit(10).addSnapshotListener(this, new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(QuerySnapshot queryDocumentSnapshots, FirebaseFirestoreException e) {
                try {
                    for (DocumentChange c : queryDocumentSnapshots.getDocumentChanges()) {
                        if (c.getType() == DocumentChange.Type.ADDED) {
                            NewMoviesModel moviesModelss = c.getDocument().toObject(NewMoviesModel.class);
                            moviesModel.add(moviesModelss);
                            moviesAdapter.notifyDataSetChanged();
                        }
                    }

                } catch (NullPointerException ep) {
                    Log.d("HomeActivity", ep.getMessage());
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        makeRefresh2();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_menu, menu);
        MenuItem manuItem = menu.findItem(R.id.app_bar_search);
        SearchView searchView = (SearchView) manuItem.getActionView();

        searchView.setOnQueryTextListener(this);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.refresh) {
            makeRefresh();
        }
        if (item.getItemId() == R.id.all) {
            Intent allmovies = new Intent(HomeActivity.this, AllMoviesActivity.class);
            startActivity(allmovies);
        }


        return true;
    }

    private void makeRefresh() {
        final ProgressDialog dialog = new ProgressDialog(this);
        dialog.setMessage("Refreshing...");
        dialog.show();
        try {
            moviesModel.clear();
            makeFetch();

        } catch (Exception ep) {
            ep.printStackTrace();
        }
        Handler handler = new Handler();
        Runnable r = new Runnable() {
            @Override
            public void run() {
                dialog.dismiss();
            }
        };
        handler.postDelayed(r, 3000);
    }

    private void makeRefresh2() {
        /*final ProgressDialog dialog = new ProgressDialog(this);
        dialog.setMessage("Refreshing...");
        dialog.show();*/
        try {
            moviesModel.clear();
            makeFetch();

        } catch (Exception ep) {
            ep.printStackTrace();
        }
        /*Handler handler = new Handler();
        Runnable r = new Runnable() {
            @Override
            public void run() {
               // dialog.dismiss();
            }
        };
        handler.postDelayed(r, 3000);*/
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        String s = newText.toLowerCase().toString();
        makeSearch(s);
        return true;
    }

    private void makeSearch(String search) {
        ArrayList<NewMoviesModel> newList = new ArrayList<>();
        for (NewMoviesModel o : moviesModel) {
            if (o.getMovie_original_title().toLowerCase().contains(search.toLowerCase())) {
                newList.add(o);
            }
        }
        NewMoviesAdapter adp = new NewMoviesAdapter(HomeActivity.this, newList);
        recyclerView.setAdapter(adp);
        adp.notifyDataSetChanged();
    }


    class AutoSlide extends TimerTask {

        @Override
        public void run() {
            HomeActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (viewPager.getCurrentItem() < splash.size() - 1) {
                        viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
                    } else {
                        viewPager.setCurrentItem(0);
                    }
                }
            });

        }
    }


}
